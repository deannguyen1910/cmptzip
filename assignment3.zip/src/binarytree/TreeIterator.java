package binarytree;
import java.util.Iterator;

public class TreeIterator<T> implements Iterator<T> {
    BTNode<T> root;
    BTNode<T> current;
    TreeIterator(BTNode<T> root){
        this.root = root;
    }
    @Override
    public boolean hasNext() {
        try {
            if (current == null){
                if (root != null){
                    return true;
                }else{
                    return false;
                }
            }else{
                BTNode<T> temp = current;
                if (temp.getLeftChild() != null){
                    return true;
                }
                if (temp.getRightChild() != null) {
                    return true;
                }
                while (temp.getParent().getRightChild() == temp) {
                    temp = temp.getParent();
                    if (temp == root) {
                        return false;
                    }
                }
                if (temp.getParent().getRightChild() != temp && temp.getParent().getRightChild() != null) {
                    return true;
                }
            }
        }catch (Exception e){
            return false;
        }
        return false;
    }
    @Override
    public T next() {
        try {
            if (current == null){
                current = root;
                return current.getData();
            }else{
                if (current.getLeftChild() != null){
                    current = current.getLeftChild();
                    return current.getData();
                }
                if (current.getRightChild() != null) {
                    current = current.getRightChild();
                    return current.getData();
                }
                while (current.getParent().getRightChild() == current) {
                    current = current.getParent();
                    if (current == root) {
                        if (root.getLeftChild() == current) break;
                        throw new Exception("Exceed the binary tree");
                    }
                }
                if (current.getParent().getRightChild() != current && current.getParent().getRightChild() != null) {
                    current = current.getParent().getRightChild();
                    return current.getData();
                }
            }
        }catch (Exception e){
            throw new IllegalArgumentException(e);
        }
        return current.getData();
    }

    @Override
    public void remove() {
        Iterator.super.remove();
    }

}