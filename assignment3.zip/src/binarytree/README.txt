There was no changes. 

I did try the test cases. It is mostly Ok except, for cases that has large N (which lead to StackOverFlowError as N is too much for stack-recursion) and 37. 

I use JDK17 so I wonder the error you have when checking my work. 

Thank you.
