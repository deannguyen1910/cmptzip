package binarytree;

import java.util.*;
import java.util.function.Function;

public class BinaryTree<T> {

	private BTNode<T> root;
	public BinaryTree(BTNode<T> root) {
		this.root = root;
	}

	public BTNode<T> getRoot() {
		return root;
	}

	public int size() {
		return root.size();
	}

	public int height() {
		return root.height();
	}

	public void printInOrder() {
		root.printInOrder();
	}

	public void printPreOrder() {
		root.printPreOrder();
	}

	public void printPostOrder() {
		root.printPostOrder();
	}

	/**************** Assignment 3 *************************/


	private int traverseCountLeaf(BTNode<T> Node){
		if (Node.isLeaf()){
			return 1;
		}else{
			if (Node.getLeftChild() != null && Node.getRightChild() != null){
				return traverseCountLeaf(Node.getLeftChild()) + traverseCountLeaf(Node.getRightChild());
			}
			if (Node.getLeftChild() != null){
				return traverseCountLeaf(Node.getLeftChild());
			}
			if (Node.getRightChild() != null){
				return traverseCountLeaf(Node.getRightChild());
			}
		}
		return 0;
	}
	/**
	 * returns the number of leaves in the tree
	 */
	public int numberOfLeaves() {
		return traverseCountLeaf(root);
	}

	/**
	 * returns the number of vertices at depth k if k<0 throws
	 * IllegalArgumentException
	 */
	private int traverseCountDepthK(BTNode<T> Node, int depthK, int currentDepth){
		if (currentDepth == depthK){
			return 1;
		}
		if (!Node.isLeaf()){
			if (Node.getLeftChild() != null && Node.getRightChild() != null){
				return traverseCountDepthK(Node.getLeftChild(), depthK, currentDepth + 1) + traverseCountDepthK(Node.getRightChild(), depthK, currentDepth + 1);
			}
			if (Node.getLeftChild() != null){
				return traverseCountDepthK(Node.getLeftChild(), depthK, currentDepth + 1);
			}
			if (Node.getRightChild() != null){
				traverseCountDepthK(Node.getRightChild(), depthK, currentDepth + 1);
			}
		}else{
			return 0;
		}
		return 0;
	}

	public int countDepthK(int k) {
		try{
			if(k < 0){
				throw new Exception("k < 0");
			}else{
				return traverseCountDepthK(root, k, 0);
			}
		}catch(Exception e){
			throw new IllegalArgumentException();
		}
	}

	//Function is a hashmap obj/lib.
	private void traverseMap(Function<? super T, ? extends T> mapper, BTNode<T> Node){
		Node.setData(mapper.apply(Node.getData()));
		if (!Node.isLeaf()){
			if (Node.getLeftChild() != null){
				traverseMap(mapper, Node.getLeftChild());
			}
			if(Node.getRightChild() != null){
				traverseMap(mapper, Node.getRightChild());
			}
		}
	}

	public void map(Function<? super T, ? extends T> mapper) {
		traverseMap(mapper, root);
	}

	
	/**
	 * returns a list containing the path from the root to the node if node is not
	 * in the tree, throws IllegalArgumentException
	 */
	private boolean doesContain(BTNode<T> node, BTNode<T> currentNode){
		if (node == currentNode){
			return true;
		}else{
			if (currentNode.getLeftChild() != null && currentNode.getRightChild() != null){
				return doesContain(node, currentNode.getLeftChild()) || doesContain(node, currentNode.getRightChild());
			}
			if (currentNode.getLeftChild() != null){
				return doesContain(node, currentNode.getLeftChild());
			}
			if (currentNode.getRightChild() != null){
				return doesContain(node, currentNode.getRightChild());
			}
			if (currentNode.getLeftChild() == null && currentNode.getRightChild() == null){
				return false;
			}
		}
		return false;
	}

	public List<BTNode<T>> pathFromRoot(BTNode<T> node){
		try{
			if (!doesContain(node, root)){
				throw new Exception("Does not contain");
			}
			BTNode<T> temp = node;
			List<BTNode<T>> ret = new LinkedList<BTNode<T>>();
			ret.add(0, temp);
			while (!temp.isRoot()){
				temp = temp.getParent();
				ret.add(0, temp);
			}
			return ret;
		}catch (Exception e){
			throw new IllegalArgumentException(e);
		}
	}
	
	/**
	 * returns the distance between the two nodes if on of the nodes is not in the
	 * tree, throws IllegalArgumentException
	 */
	public int distance(BTNode<T> node1, BTNode<T> node2) {
		List<BTNode<T>> path1 = new LinkedList<BTNode<T>>();
		List<BTNode<T>> path2 = new LinkedList<BTNode<T>>();
		path1 = pathFromRoot(node1);
		path2 = pathFromRoot(node2);
		for(int i = path1.size() - 1; i >= 0; i--){
			for (int j = path2.size() - 1; j >= 0; j--){
				if (path1.get(i) == path2.get(j)){
					return path1.size() - i + path2.size() - j - 2;
				}
			}
		}
		return 0;
	}

	
	/**
	 * returns a preOrder iterator for the tree
	 */
	public Iterator<T> preOrderIterator() {
		TreeIterator<T> a = new TreeIterator<T>(root);
		return  a;
	}
}