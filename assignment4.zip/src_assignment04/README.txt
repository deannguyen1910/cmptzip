I changed the Exception throw only. Unlike in JDK 17, JDK 11 doesn't throw Exception(e). e is a referenece contains a string informed when throw in try.
