package graph;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Iterator;

public class Graph {
	int[][] graphMatrix;
	int size;

	/**
	 * creates an empty graph on n nodes
	 * the "names" of the vertices are 0,1,..,n-1 
	 * @param n - number of vertices in the graph
	 */
	public Graph(int n) {
		size = n;
		graphMatrix = new int[size][size];
		for(int i = 0; i < size; i++){
			for (int j = 0; j < size; j++){
				graphMatrix[i][j] = 0;
			}
		}
	}

	/**
	 * adds the edge (i,j) to the graph  
	 * no effect if i and j were already adjacent
	 * @param i, j - vertices in the graph
	 */
	public void addEdge(int i, int j) {
		graphMatrix[i][j] = 1;
		graphMatrix[j][i] = 1;
	}

	/**
	 * removes the edge (i,j) from the graph
	 * no effect if i and j were not adjacent
	 * @param i, j - vertices in the graph
	 */
	public void removeEdge(int i, int j) {
		graphMatrix[i][j] = 0;
		graphMatrix[j][i] = 0;
	}

	/**
	 * @param i, j - vertices in the graph
	 * @return true if (i,j) is an edge in the graph, and false otherwise
	 */
	public boolean areAdjacent(int i, int j) {
		if (graphMatrix[i][j] == 1 && graphMatrix[j][i] == 1) return true;
		else return false;
	}

	/**
	 * @param i, j - vertices in the graph
	 * @return true if distance(i,j)<=2, and false otherwise
	 */
	public boolean distanceAtMost2(int i, int j) {
		if (areAdjacent(i, j)) return true;
		else {
			for (int count_vertex = 0; count_vertex < size; count_vertex++) {
				if (count_vertex == i || count_vertex == j) continue;
				else {
					if (areAdjacent(i, count_vertex) && areAdjacent(count_vertex, j)) return true;
				}
			}
		}
		return false;
	}

	/**
	 * @param i - a vertex in the graph
	 * @return the degree of i
	 */
	public int degree(int i) {
		int count = 0;
		for (int row = 0; row < size; row++){
			count += graphMatrix[i][row];
		}
		return count;
	}
	
	/**
	 * The iterator must output the neighbors of i in the increasing order
	 * Assumption: the graph is not modified during the use of the iterator 
	 * @param i - a vertex in the graph
	 * @return an iterator that returns the neighbors of i
	 */
	public Iterator<Integer> neighboursIterator(int i) {
		ArrayList<Integer> temp = new ArrayList<Integer>();

		for (int column = 0; column < size; column++){
			if (column == i) continue;
			if (areAdjacent(i, column)) temp.add(column);
		}

		return temp.iterator();
	}

	/**
	 * @return number of vertices in the graph
	 */
	public int numberOfVertices() {
		return size;
	}

	/**
	 * @return number of edges in the graph
	 */
	public int numberOfEdges() {
		int count = 0;
		for (int i = 0; i < size; i++){
			for (int j = 0; j < size; j++){
				count += graphMatrix[i][j];
				if (j > i) {j = size + 1;}
			}
		}

		return count;
	}

	/**
	 * @param n - number of vertices
	 * @param p - number between 0 and 1
	 * @return a random graph on n vertices, where each edge is added to the graph with probability p
	 */
	public static Graph generateRandomGraph(int n, double p) {
		Graph temp = new Graph(n);
		for (int i = 0; i < n; i++){
			for (int j = 0; j < n; j++){
				if (i >= j){
					if (Math.random() < p) {
						temp.addEdge(i, j);
					}
				}else{
					continue;
				}
			}
		}
		return temp;
	}

	public String toString(){
		String temp = "";
		for (int i = -1; i < size; i++){
			if (i == -1) {
				temp += "   c0 c1 c2 c3 c4 c5 c6 c7 c8 c9\n";
				continue;
			}
			temp += "r" + i + " ";
			for (int j = 0; j < size; j++){
				temp += graphMatrix[i][j];
				temp += "  ";
			}
			temp += "\n";
		}

		return temp;
	}

}
