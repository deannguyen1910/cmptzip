package avltree;
import java.util.*;
import java.lang.Math;
import java.util.ArrayList;

public class AVLTree<T extends Comparable<T>> {

	AVLNode<T> root;
	int size;
	int maxHeight;

	AVLNode<T> min;
	/**
	 * creates an empty AVL tree
	 */

	/**A global integer replaced UnmutableInteger (better than use a whole class to define wrapped type :D) */
	private int mutebleInteger;
	public AVLTree() {
		root = null;
		size = 0;
		int maxHeight = 0;
	}

	private void rightRightRotate(AVLNode<T> node){
		AVLNode<T> tempParent = null;
		boolean isLeftChildOfParent = false;
		if (node != root){
			tempParent = node.getParent();
			isLeftChildOfParent = node.isLeftChildOfParent();
		};


		AVLNode<T> head = node;  /// will be left node of right
		AVLNode<T> right = node.getRightChild();  /// this will be new head
		//AVLNode<T> rightRight = right.getRightChild(); // no change so no need
		AVLNode<T> rightLeft = null;
		if (right.getLeftChild() != null){rightLeft = right.getLeftChild();}

		right.setLeftChild(head);
		head.setParent(right);

		head.setRightChild(rightLeft);
		if (rightLeft != null) rightLeft.setParent(head);

		right.setParent(tempParent);
		if (tempParent != null){ // case that node IS NOT root
			if (isLeftChildOfParent){tempParent.setLeftChild(right);}
			else							{tempParent.setRightChild(right);}
		}
		else{
			root = right;
			root.setParent(null);
		} // case that node IS root
	}
	private void rightLeftRotate(AVLNode<T> node){
		AVLNode<T> tempParent = null;
		boolean isLeftChildOfParent = false;
		if (node != root) {
			tempParent = node.getParent();
			isLeftChildOfParent = node.isLeftChildOfParent();
		}
		AVLNode<T> head = node; // this will be left node of rightLeft
		AVLNode<T> right = node.getRightChild(); // will be right node of rightLeft
		AVLNode<T> rightLeft = right.getLeftChild(); //this will be new head

		AVLNode<T> rightLeftLeft = null;
		if (rightLeft.getLeftChild() != null){rightLeftLeft = rightLeft.getLeftChild();}
		AVLNode<T> rightLeftRight = null;
		if(rightLeft.getRightChild() != null) {rightLeftRight = rightLeft.getRightChild();}

		rightLeft.setLeftChild(head);
		head.setParent(rightLeft);

		head.setRightChild(rightLeftLeft);
		if (rightLeftLeft != null) rightLeftLeft.setParent(head);

		rightLeft.setRightChild(right);
		right.setParent(rightLeft);

		right.setLeftChild(rightLeftRight);
		if (rightLeftRight != null) rightLeftRight.setParent(right);

		if (tempParent != null){
			if (isLeftChildOfParent){tempParent.setLeftChild(rightLeft);}
			else					{tempParent.setRightChild(rightLeft);}
		}
		else{
			root = rightLeft;
			root.setParent(null);
		}
	}
	private void leftLeftRotate(AVLNode<T> node){
		AVLNode<T> tempParent = null;
		boolean isLeftChildOfParent = false;
		if (node != root) {
			tempParent = node.getParent();
			isLeftChildOfParent = node.isLeftChildOfParent();
		}

		AVLNode<T> head = node;  /// will be left node of right
		AVLNode<T> left = node.getLeftChild();  /// this will be new head
		//AVLNode<T> leftLeft = left.getLeftChild(); // no change so no need
		AVLNode<T> leftRight = null;
		if (left.getRightChild() != null){leftRight = left.getRightChild();}

		left.setRightChild(head);
		head.setParent(left);

		head.setLeftChild(leftRight);
		if (leftRight != null){ leftRight.setParent(head);}

		left.setParent(tempParent);
		if (tempParent != null){ // case that node IS NOT root
			if (isLeftChildOfParent){tempParent.setLeftChild(left);}
			else					{tempParent.setRightChild(left);}
		}
		else{
			root = left;
			root.setParent(null);
		} // case that node IS root

	}
	private void leftRightRotate(AVLNode<T> node){
		AVLNode<T> tempParent = null;
		boolean isLeftChildOfParent = false;
		if (node != root) {
			tempParent = node.getParent();
			isLeftChildOfParent = node.isLeftChildOfParent();
		}

		AVLNode<T> head = node; // this will be left node of rightLeft
		AVLNode<T> left = node.getLeftChild(); // will be right node of rightLeft
		AVLNode<T> leftRight = left.getRightChild(); //this will be new head

		AVLNode<T> leftRightRight = null;
		if (leftRight.getRightChild() != null){leftRightRight = leftRight.getRightChild();}
		AVLNode<T> leftRightLeft = null;
		if(leftRight.getLeftChild() != null) {leftRightLeft = leftRight.getLeftChild();}

		leftRight.setRightChild(head);
		head.setParent(leftRight);

		head.setLeftChild(leftRightRight);
		if (leftRightRight != null) leftRightRight.setParent(head);

		leftRight.setLeftChild(left);
		left.setParent(leftRight);

		left.setRightChild(leftRightLeft);
		if (leftRightLeft != null) leftRightLeft.setParent(left);

		if (tempParent != null){
			if (isLeftChildOfParent){tempParent.setLeftChild(leftRight);}
			else					{tempParent.setRightChild(leftRight);}
		}
		else{
			root = leftRight;
			root.setParent(null);
		}
	}

	/**
	 * Return the value of max_depth_from_right_child_of_this_node - max_depth_from_left_child_of_this_node
	 * */
	private int rightDepth_largerThan_leftDepth(AVLNode<T> node){
		int leftDepth, rightDepth;
		if (node.getLeftChild() != null){
			leftDepth = getMaxDepthFrom(node.getLeftChild());
		}
		else{
			leftDepth = heightOf(node);
		}
		if (node.getRightChild() != null){
			rightDepth = getMaxDepthFrom(node.getRightChild());  // what if they don't have
		}
		else{
			rightDepth = heightOf(node);
		}

		return rightDepth - leftDepth;
	}
	private void balance(AVLNode<T> node){
		//find the node that have two 2 children
		while(node != null){
			if (node.getLeftChild() == null && node.getRightChild() == null){
				node = node.getParent();}
			else{
				//calculate the depth of each left-right node if unbalancing happens
				int rightDepth_largerThan_leftDepth = rightDepth_largerThan_leftDepth(node);

				if (rightDepth_largerThan_leftDepth >= 2) {
					//this node is unbalanced

					/**
					 * if either node.getRightChild().getRightChild() has deeper node then it would be rightRightCase
					 * or otherwise*/
					if (rightDepth_largerThan_leftDepth(node.getRightChild()) >= 0){
						rightRightRotate(node);
					}else{
						rightLeftRotate(node);
					}
					return;
				}
				if (rightDepth_largerThan_leftDepth <= -2) {
					if (rightDepth_largerThan_leftDepth(node.getLeftChild()) > 0){
						leftRightRotate(node);
					}else{
						leftLeftRotate(node);
					}
					return;
				}

				if (node == root) break;
				node = node.getParent();
			}
		}
	}
	private int heightOf(AVLNode<T> node){
		try {
			AVLNode<T> temp = node;
			int count = 0;
			while (temp != root) {
				if (temp.getParent() != null) {
					temp = temp.getParent();
					count++;
				}else{
					if (temp != root){
						throw new NoSuchElementException("Not belongs to this Tree");
					}
				}
			}
			return count;
		}catch(NoSuchElementException e){
			throw new NoSuchElementException("Not belongs to this Tree");
		}
	}
	private void traverseGetMaxDepthFrom(AVLNode<T> node, int currentLevel){
		if (node.isLeaf()){
			if (currentLevel > mutebleInteger){
				mutebleInteger = currentLevel;
			}
		}else {
			if (node.getLeftChild() != null) {
				traverseGetMaxDepthFrom(node.getLeftChild(), currentLevel + 1);
			}
			if (node.getRightChild() != null) {
				traverseGetMaxDepthFrom(node.getRightChild(), currentLevel + 1);
			}
		}
	}
	private int getMaxDepthFrom(AVLNode<T> node){
		mutebleInteger = 0;
		traverseGetMaxDepthFrom(node, heightOf(node));
		return mutebleInteger;
	}

	/**
	 * returns a node containing item in the AVL tree
	 * if item is not in the tree, throws NoSuchElementException
	 */
	public AVLNode<T> find(T item) {
		try{
			AVLNode<T> tempNode = root;
			while(tempNode != null) {
				if (item.compareTo(tempNode.getData()) == 0) return tempNode;

				if (item.compareTo(tempNode.getData()) < 0) { // item < tempNode
					if (tempNode.getLeftChild() != null){
						tempNode = tempNode.getLeftChild();
					}else{
						throw new NoSuchElementException();
					}
				} else {
					if (tempNode.getRightChild()!= null){
						tempNode = tempNode.getRightChild();
					}else{
						throw new NoSuchElementException();
					}
				}
			}
			return null;
		}catch(NoSuchElementException e){
			throw e;
		}
	}

	/**
	 * adds a new item to the AVL tree
	 * duplicates are allowed
	 */
	public AVLNode<T> insert(T item) {
		size++;
		if (root == null){
			root = new AVLNode<T>(item);
			min = root;
			return root;
		}
		else {
			/**
			 * Insert item into tree
			 */
			AVLNode<T> tempNode = root;
			while(true){
				if (item.compareTo(tempNode.getData()) < 0){
					if (tempNode.getLeftChild() == null){
						AVLNode<T> tempNewNode = new AVLNode<T>(item);
						tempNode.setLeftChild(tempNewNode);
						tempNode = tempNode.getLeftChild();
						break;
					}else{
						tempNode = tempNode.getLeftChild();

					}
				}else{
					if (tempNode.getRightChild() == null){
						AVLNode<T> tempNewNode = new AVLNode<T>(item);
						tempNode.setRightChild(tempNewNode);
						tempNode = tempNode.getRightChild();
						break;
					}else{
						tempNode = tempNode.getRightChild();
					}
				}
			}

			AVLNode<T> _TEMP_RETURN = tempNode;
			/**
			 * Balancing the tree
			 */
			balance(tempNode);
			fetchMinAfterInsert();
			return _TEMP_RETURN;
		}
	}


	/**
	 * remove item from the AVL tree
	 * if item is not in the tree, throws NoSuchElementException
	 */

	private AVLNode<T> getMaxButLessThan(AVLNode<T> node){
		AVLNode<T> tempNode = node;
		if (tempNode.getLeftChild() != null){
			tempNode = tempNode.getLeftChild();
			while(tempNode.getRightChild() != null){
				tempNode = tempNode.getRightChild();
			}
			return tempNode;
		}
		else{
			return null;
		}
	}

	private AVLNode<T> getMinButLargerThan(AVLNode<T> node){
		AVLNode<T> tempNode = node;
		if (tempNode.getRightChild() != null){
			tempNode = tempNode.getRightChild();
			while(tempNode.getLeftChild() != null){
				tempNode = tempNode.getLeftChild();
			}
			return tempNode;
		}
		else{
			return null;
		}
	}

	public void remove(T item) {
		try{
			AVLNode<T> removedNode = find(item);
			if (removedNode == null){ // case that there is no item
				return;
			}

			size--;
			if (removedNode.isLeaf()){ // case that is leaf - very bottom
				if (removedNode == root) {
					root = null;
					min = null;
					return;
				}
				AVLNode<T> tempParent = removedNode.getParent();
				fetchMinAfterRemove(removedNode);
				if(removedNode.isLeftChildOfParent()){ // there is always parent node
					removedNode.getParent().setLeftChild(null);
				}else{
					removedNode.getParent().setRightChild(null);
				}
				balance(tempParent);
				return;
			}

			AVLNode<T> replacedNode = getMaxButLessThan(removedNode);
			if (replacedNode != null) {
				if (replacedNode == removedNode.getLeftChild()) {
					AVLNode<T> temp = replacedNode.getLeftChild();
					removedNode.setLeftChild(temp);
				}
				else {
					AVLNode<T> temp = replacedNode.getLeftChild();
					replacedNode.getParent().setRightChild(temp);
					if (temp != null){ temp.setParent(replacedNode.getParent());}
				}
				if (removedNode == root) {
					root = removedNode.assign(replacedNode);
					root.setParent(null);
				}else{
					removedNode.assign(replacedNode);
				}
				balance(replacedNode);
				return;
			}

			replacedNode = getMinButLargerThan(removedNode);
			if (replacedNode != null){
				if (replacedNode == removedNode.getRightChild()){
					AVLNode<T> temp = replacedNode.getRightChild();
					removedNode.setRightChild(temp);
				}
				else{
					AVLNode<T> temp = replacedNode.getRightChild();
					replacedNode.getParent().setLeftChild(temp);
					if (temp != null){temp.setParent(replacedNode.getParent());}
				}
				if (removedNode == root){
					root= removedNode.assign(replacedNode);
					root.setParent(null);
				}else{
					removedNode.assign(replacedNode);
				}
				balance(replacedNode);
				return;
			}



		}catch(NoSuchElementException e){
			throw e;
		}


		//balance
	}

	/**
	 * returns the height of the tree in O(1) time
	 */
	public int height() {
		double result = Math.log(size + 1) / Math.log(2);
		if(result - (int)result == 0){ // if result is integer
			maxHeight = (int)result - 1;
			return (int)result - 1;
		}else{
			maxHeight = (int)result;
			return (int)result;
		}
	}

	/**
	 * returns the size of the tree in O(1) time
	 */
	public int size() {
		return size;
	}

	/**
	 * returns the minimal element of the tree in O(1) time
	 */
	private void fetchMinAfterInsert(){
		if (min.getLeftChild() != null){
			min = min.getLeftChild();
		}
	}

	private void fetchMinAfterRemove(AVLNode<T> removedNode){
		if (removedNode == min){
			AVLNode<T> temp = min.getParent();
			min = temp;
		}
	}
	public T getMin() {
		return min.getData();
	}

	/**
	 * returns a collection of all elements in the tree for which
	 * element.compareTo(k) < 0
	 * If the list is empty, returns an empty list
	 */

	private void traverseInOrderLessThanK(ArrayList<T> listLessThanK, T k, AVLNode<T> node){
		if (node.getLeftChild() != null){
			traverseInOrderLessThanK(listLessThanK, k, node.getLeftChild());
		}
		if (node.getRightChild() != null){
			traverseInOrderLessThanK(listLessThanK, k, node.getRightChild());
		}
		if (node.getData().compareTo(k) < 0){
			listLessThanK.add(node.getData());
		}else{
			return;
		}
	}

	public Collection<T> lessThanK(T k) {
		ArrayList<T> listLessThanK = new ArrayList<T>();
		traverseInOrderLessThanK(listLessThanK, k, root);
		
		return listLessThanK;
	}

	public AVLNode<T> getRoot() {
		return root;
	}
}
