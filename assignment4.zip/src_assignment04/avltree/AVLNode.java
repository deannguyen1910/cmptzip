package avltree;

public class AVLNode<T extends Comparable<T>> {
	private T data;

	private AVLNode<T> leftChild;
	private AVLNode<T> rightChild;
	private AVLNode<T> parent;

 	public AVLNode(T data) {
		this.data = data;
		this.leftChild = null;
		this.rightChild = null;
		this.parent = null;
	}

	public AVLNode(T data, AVLNode<T> left, AVLNode<T> right, AVLNode<T> parent) {
		this.data = data;
		this.leftChild = left;
		this.rightChild = right; 
		this.parent = parent;
	}

	protected boolean isLeftChildOfParent(){
		 try {
			 if (parent == null) {
				 throw new IllegalArgumentException("It doesn't have parent");
			 }

			 if (parent.getLeftChild() != null && parent.getLeftChild() == this) {
				 return true;
			 }
			 if (parent.getRightChild() != null && parent.getRightChild() == this) {
				 return false;
			 }
		 }catch (Exception e){
			 throw e;
		 }
		 return true;
	}
	public T getData() {
		return data;
	}

	protected AVLNode<T> assign(AVLNode<T> newNode){
		 if (this.parent != null){
			 newNode.setParent(this.parent);

			 if (this.isLeftChildOfParent()){
				parent.setLeftChild(newNode);
			 }
			 else{
				parent.setRightChild(newNode);
			 }
		 }

		 newNode.setRightChild(this.rightChild);
		 newNode.setLeftChild(this.leftChild);
		 if (this.rightChild != null){
			 rightChild.setParent(newNode);
		 }

		 if (this.leftChild != null){
			 leftChild.setParent(newNode);
		 }

		 return newNode;
	}

	public AVLNode<T> getLeftChild() {
		return leftChild;
	}

	public AVLNode<T> getRightChild() {
		return rightChild;
	}

	public AVLNode<T> getParent() {
		return parent;
	}

	public void setData(T data) {
		this.data = data;
	}

	public void setLeftChild(AVLNode<T> leftChild) {
		this.leftChild = leftChild;
		if (leftChild != null){
			leftChild.parent = this;
		}
	}

	public void setRightChild(AVLNode<T> rightChild) {
		this.rightChild = rightChild;
		if (rightChild != null){
			rightChild.parent = this;
		}
	}

	public void setParent(AVLNode<T> parent) {
		this.parent = parent;
	}
	
	public boolean isLeaf() {
		return (getLeftChild() == null && getRightChild() == null);
	}

	public boolean isRoot() {
		return (getParent() == null);
	}
}
